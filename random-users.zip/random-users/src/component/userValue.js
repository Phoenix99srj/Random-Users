import React, { useEffect, useState } from 'react';

function Users() {
  // Declare a new state variable, which we'll call "count"
  const handleLoadFunction = async () => {
  await fetch("https://randomuser.me/api")
    .then((response) => response.json())
    .then((user) => {
      user.results.map(result => 
        {
            setEmail(result.email);
            return setFullName(result.name.title + " " + result.name.first + " " + result.name.last); 
          });
    });
  }
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");

  useEffect(() => {
    handleLoadFunction();
  }, []);
  if (fullName){
    localStorage.setItem("full Name", fullName);
  }
  if (email){
    localStorage.setItem("email", email);
  }

  return (
    <div className='component-app'>
        <div className='heading-block'>
      <h5>Full Name: {fullName}</h5>
      <h5>Email: {email}</h5>
      </div>
      <button className='btn' onClick={handleLoadFunction}>
        Refresh
      </button>
     
    </div>
  );
}
export default Users;