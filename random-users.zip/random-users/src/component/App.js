import React from "react";
import "./App.css";
import Users from "./userValue";

export default class App extends React.Component {

  render() {
    return (
      <div className="component-app">
       <Users />
      </div>
    );
  }
}
