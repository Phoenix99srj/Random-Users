User Data
---


Install
---
1. Install Node JS from `https://nodejs.org/en/download/`
2. Type `npm install` in the command line


Usage
---

`npm start`
